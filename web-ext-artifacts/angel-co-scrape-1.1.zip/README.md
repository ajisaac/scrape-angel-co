# scrape-angel-co

A simple firefox browser extension to extract important
information from a single job posting from angel.co.

## why

Amongst job boards, angel.co has got to be one of the
more difficult websites to scrape, they really have a 
high level of defenses. Best I could do was to manually
scrape each posting using a plugin loaded directly 
in the page.